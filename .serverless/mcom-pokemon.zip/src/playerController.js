


class playerController {
    
    pokemon = []

    addPokemon = async () => {
        
    }
}

class pokemon {
    x
    y
    imgSrc
    frontImg
    backImg
}